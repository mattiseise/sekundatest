﻿using UnityEngine;
using System.Collections;

public class Rocket : MonoBehaviour 
{
	private Rigidbody2D rigid;
	public float launchPower;
	public bool rotateRight;
	public float rotateSpeed;

	private Animator anim;
	public AnimationClip explosionClip;

	void Awake ()
	{
		rigid = GetComponent<Rigidbody2D> ();
		anim = GetComponent<Animator> ();
	}

	void Start () 
	{
		rigid.AddForce (transform.right * launchPower);
		if (facingRight () == true)
		{
			rotateRight = true;
		} 

		else 
		{
			rotateRight = false;
		}
	}

	void Update ()
	{
		if (rotateRight == true) 
		{
			transform.Rotate (0, 0, -rotateSpeed * Time.deltaTime);
		} 

		else
		{
			transform.Rotate (0, 0, rotateSpeed * Time.deltaTime);
		}

		if (anim.GetCurrentAnimatorStateInfo(0).IsName("Rocket Destroyed"))
		{
			Destroy (gameObject);
		}
	}

	bool facingRight()
	{
		if (transform.eulerAngles.z > 30.0f && transform.eulerAngles.z < 140.0f)
		{
			return true;
		}

		else
		{
			return false;
		}
	}

	void OnCollisionStay2D(Collision2D col)
	{
	    if (col.gameObject.layer != 8) 
		{
			anim.Play ("Rocket Explosion");
			rigid.isKinematic = true;	
		} 
	}
}