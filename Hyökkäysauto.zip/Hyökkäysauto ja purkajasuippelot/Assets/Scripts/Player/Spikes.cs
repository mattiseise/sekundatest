﻿using UnityEngine;
using System.Collections;

public class Spikes : MonoBehaviour 
{
	public AnimationCurve curve;
	public float time;
	public float spikeSpeed;

	void Update()
	{
		time += spikeSpeed * Time.deltaTime;
		transform.localPosition = new Vector2(curve.Evaluate (time) + 0.3f, -0.025f);
		if (time > 1)
		{
			gameObject.SetActive (false);
		}
	}
}