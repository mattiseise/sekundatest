﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class PlayerCamera : MonoBehaviour 
{
	public GameObject player;
	public float smoothTime;
	private Vector2 velocity = Vector2.zero;
	private float offset = -10.0f;
		
	void FixedUpdate () 
	{
		if(player == true)
		{
			Vector2 targetPosition = player.transform.TransformPoint(new Vector3(0, 0));
			transform.position = Vector2.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
			transform.position = new Vector3 (transform.position.x, transform.position.y, offset);
		}

		if(Input.GetKeyDown(KeyCode.R))
		{
			SceneManager.LoadScene("Hyökkäysauto");
		}

		if(Input.GetKeyDown(KeyCode.Escape))
		{
			Application.Quit();
		}
	}
}