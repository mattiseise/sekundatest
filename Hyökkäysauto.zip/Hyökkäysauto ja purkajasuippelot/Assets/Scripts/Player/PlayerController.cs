﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
	private Rigidbody2D rigid;

	public float acceleration;
	public float maxSpeed;
	private float velocity = 0;

	public float jumpPower;
	public float jumpRayLength;
	public LayerMask layerMask;

	public GameObject spikes;
	public Spikes spikeAttack;

	public GameObject plasmaGun;
	public GameObject plasmaBullet;
	public float plasmaGasUsage;
	public float fireRate;
	private float nextFire;

	public GameObject rocketLauncher;
	public GameObject rocket;
	public int rockets = 100;
	public RocketsQuantity rocketsQuantity;

	public float hp;
	public float maxHp;

	public float gas;
	public float maxGas;

	private Animator anim;

	private Vector3 startLocalScale = new Vector3(3, 3, 1);

	public GameObject gameOverText;

	public float roofDamage;

	void Awake ()
	{
		rigid = GetComponent<Rigidbody2D> ();
		anim = GetComponent<Animator> ();
	}

	void Start () 
	{
		hp = maxHp;
		gas = maxGas;
		rocketsQuantity.updateText();
	}

	void FixedUpdate ()
	{
		float xInput = Input.GetAxis ("Horizontal");

		Vector2 movement = new Vector2 (xInput * velocity, rigid.velocity.y);

		if (xInput != 0 && velocity < maxSpeed) 
		{
			velocity += acceleration;
		}

		else if(xInput == 0 && velocity > 1)
		{
			velocity -= 1;
		}

		if(velocity > maxSpeed)
		{
			velocity = maxSpeed;
		}

		if (xInput > 0 && checkJump() == true)
		{
			transform.localScale = new Vector3 (startLocalScale.x, startLocalScale.y, startLocalScale.z);
		} 

		else if (xInput < 0 && checkJump() == true) 
		{
			transform.localScale = new Vector3 (-startLocalScale.x, startLocalScale.y, startLocalScale.z);
		}

		if (checkJump () == true && gas > 0) 
		{
			rigid.velocity = movement;
		}

		if (Input.GetButtonDown ("Jump") && checkJump() == true) 
		{
			rigid.AddForce (transform.up * jumpPower);
		}

		if (Input.GetButton ("Fire1")) 
		{
			if(spikes.activeInHierarchy == false)
			{
				spikeAttack.time = 0;
				spikes.SetActive (true);
			}
		}
			
		if (Input.GetButton ("Fire2") && Time.time > nextFire)
		{
			nextFire = Time.time + fireRate;
			plasmaGun.SetActive (true);
			Instantiate (plasmaBullet, plasmaGun.transform.position, Quaternion.Euler(0, checkPlasmaBulletDirection(), transform.eulerAngles.z));
			gas -= plasmaGasUsage;
		}
			
		if (Input.GetButton ("Fire3") && Time.time > nextFire && rockets > 0)
		{
			nextFire = Time.time + fireRate;
			rocketLauncher.SetActive (true);
			Instantiate (rocket, rocketLauncher.transform.position, Quaternion.Euler(0, 0, checkRocketDirection()));
			rockets -= 1;
			rocketsQuantity.updateText();
		}

		if(Input.GetKeyDown(KeyCode.Escape))
		{
			Application.Quit();
		}
			
		if(Time.time > nextFire)
		{
			plasmaGun.SetActive (false);
			rocketLauncher.SetActive (false);
		}
			
		if (xInput != 0 && hp > 0 && gas > 0)
		{
			gas -= 1;
			anim.Play ("Movement");
		}

		if(gas == 0)
		{
			hp = 0;
		}

		if(hp <= 0)
		{
			rigid.isKinematic = true;
			anim.Play ("Explosion");
			spikes.SetActive(false);
			plasmaGun.SetActive(false);
			rocketLauncher.SetActive(false);
		}

		if (anim.GetCurrentAnimatorStateInfo (0).IsName ("Destroyed")) 
		{
			gameObject.SetActive(false);
			gameOverText.SetActive(true);
		}

		if (gas > maxGas) 
		{
			gas = maxGas;
		}

		else if(gas < 0)
		{
			gas = 0;
		}

		if (xInput == 0 && hp > 0) 
		{
			anim.Play ("Default");
		}

		RaycastHit2D hit = Physics2D.Raycast (transform.position, transform.up, jumpRayLength, layerMask);
		Debug.DrawRay (transform.position, transform.up * jumpRayLength, Color.red);
		if(hit == true)
		{
			hp -= roofDamage;
		}

		if(transform.position.y <= -50)
		{
			hp = 0;
		}
	}

	bool checkJump()
	{
		RaycastHit2D hit = Physics2D.Raycast (transform.position, -transform.up, jumpRayLength, layerMask);
		Debug.DrawRay (transform.position, -transform.up * jumpRayLength, Color.red);
		if (hit == true) 
		{
			return true;
		}

		else
		{
			return false;
		}
	}

	float checkPlasmaBulletDirection()
	{
		if(transform.localScale.x == 3)
		{
			return 0;
		}

		else
		{
			return 180;
		}
	}

	float checkRocketDirection()
	{
		if(transform.localScale.x == 3)
		{
			return 45.0f;
		}

		else
		{
			return 135.0f;
		}
	}
}