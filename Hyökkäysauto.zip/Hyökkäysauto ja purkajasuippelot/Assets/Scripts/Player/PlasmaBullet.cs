﻿using UnityEngine;
using System.Collections;

public class PlasmaBullet : MonoBehaviour
{
	public float bulletSpeed;
	private float dist;
	public float targetDist;
	public GameObject player;
	private Vector2 startPos;

	void Start ()
	{
		startPos = transform.position;
	}

	void Update ()
	{
		transform.Translate (transform.right * bulletSpeed * Time.deltaTime, 0);
		dist = Vector2.Distance (startPos, transform.position);
		if(dist > targetDist)
		{
			Destroy(gameObject);
		}
	}

	void OnCollisionStay2D(Collision2D col)
	{
		if (col.gameObject.layer != 8)
		{
			Destroy (gameObject);
		}
	}
}