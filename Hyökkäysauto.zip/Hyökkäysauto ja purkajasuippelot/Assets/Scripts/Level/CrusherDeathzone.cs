﻿using UnityEngine;
using System.Collections;

public class CrusherDeathzone : MonoBehaviour
{
	public Crusher crusher;
	public PlayerController playerCtrl;

	void Start () 
	{
	
	}

	void Update () 
	{
		
	}

	void OnCollisionEnter2D(Collision2D col)
	{
		if(col.gameObject.layer == 8 && crusher.descending == true)
		{
			playerCtrl.hp = 0;
		}
	}
}