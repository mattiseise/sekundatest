﻿using UnityEngine;
using System.Collections;

public class BombExplosion : MonoBehaviour 
{
	private SpriteRenderer spriteRend;
	public Sprite bomb0;
	public Sprite bomb1;
	public Sprite bomb2;
	public Sprite bomb3;
	public Sprite bomb4;
	public Sprite bomb5;
	public Sprite bomb6;
	public float spriteChangeRate;
	private float nextSpriteChange;
	private int currentSprite = 0;
	private Sprite[] bombs = new Sprite[7];
	private BoxCollider2D boxCol;
	public PlayerController playerCtrl;

	void Awake ()
	{
		spriteRend = GetComponent<SpriteRenderer> ();
		boxCol = GetComponent<BoxCollider2D> ();
	}

	void Start () 
	{
		boxCol.enabled = false;
		bombs[0] = bomb0;
		bombs[1] = bomb1;	
		bombs[2] = bomb2;
		bombs[3] = bomb3;
		bombs[4] = bomb4;
		bombs[5] = bomb5;
		bombs[6] = bomb6;
	}

	void Update ()
	{
		if(Time.time > nextSpriteChange && currentSprite < 7)
		{
			nextSpriteChange = Time.time + spriteChangeRate;
			spriteRend.sprite = bombs[currentSprite];
			currentSprite++;
		}

		if(currentSprite == 3)
		{
			spriteChangeRate = 0.1f;

		}
		else if(currentSprite == 4)
		{
			boxCol.enabled = true;
		}
		if(currentSprite == 7)
		{
			Destroy(gameObject);
		}
	}

	void OnTriggerStay2D(Collider2D col)
	{
		if(col.gameObject.layer == 8)
		{
			playerCtrl.hp = 0;
		}
	}
}