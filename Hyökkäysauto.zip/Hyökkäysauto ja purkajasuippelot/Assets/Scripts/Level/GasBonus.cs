﻿using UnityEngine;
using System.Collections;

public class GasBonus : MonoBehaviour
{
	public PlayerController playerCtrl;
	public float gasBonus;

	void OnCollisionEnter2D(Collision2D col)
	{
		if (col.gameObject.name == "Player") 
		{
			playerCtrl.gas += gasBonus;
			Destroy (gameObject);
		}
	}
}