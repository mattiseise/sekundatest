﻿using UnityEngine;
using System.Collections;

public class StickyPlatform : MonoBehaviour 
{
	public PlayerController playerCtrl;
	public float speedReducer;
	private float maxSpeed;
	private float halvedSpeed;
	private float jumpPower;

	void Start () 
	{
		maxSpeed = playerCtrl.maxSpeed;
		halvedSpeed = playerCtrl.maxSpeed - speedReducer;
		jumpPower = playerCtrl.jumpPower;
	}

	void OnCollisionStay2D(Collision2D col)
	{
		if(col.gameObject.layer == 8)
		{
			playerCtrl.maxSpeed = halvedSpeed;
			playerCtrl.jumpPower = 0;
		}
	}

	void OnCollisionExit2D(Collision2D col)
	{
		if(col.gameObject.layer == 8)
		{
			playerCtrl.maxSpeed = maxSpeed;
			playerCtrl.jumpPower = jumpPower;
		}
	}
}