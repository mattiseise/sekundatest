﻿using UnityEngine;
using System.Collections;
using System.IO;
using UnityEngine.UI;

public class Goal : MonoBehaviour 
{
	public GameObject gameCompletedText;
	public Timer timer;

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.gameObject.layer == 8)
		{
			gameCompletedText.SetActive(true);
			timer.stopTime = true;
			col.gameObject.SetActive(false);
			if(System.IO.File.ReadAllText ("./bestTime.txt") != "" && float.Parse(System.IO.File.ReadAllText ("./bestTime.txt")) > timer.time)
			{
				System.IO.File.WriteAllText("./bestTime.txt", timer.time.ToString());
			}

			else if (System.IO.File.ReadAllText ("./bestTime.txt") != "" && float.Parse(System.IO.File.ReadAllText ("./bestTime.txt")) < timer.time)
			{
				return;
			}
			else
			{
				System.IO.File.WriteAllText("./bestTime.txt", timer.time.ToString());
			}
		}
	}
}
