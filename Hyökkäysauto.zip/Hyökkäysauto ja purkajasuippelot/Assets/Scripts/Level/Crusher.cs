﻿using UnityEngine;
using System.Collections;

public class Crusher : MonoBehaviour 
{
	public float minHeight;
	private float maxHeight;
	public float descendSpeed;
	public float ascendSpeed;
	public bool descending;

	void Start ()
	{
		maxHeight = transform.position.y;
		descending = true;
	}

	void Update () 
	{
		if (descending == true && transform.position.y > minHeight) 
		{
			transform.Translate (0, -descendSpeed * Time.deltaTime, 0);
		} 
		else 
		{
			descending = false;
		}
			
		if (descending == false && transform.position.y < maxHeight)
		{
			transform.Translate (0, ascendSpeed * Time.deltaTime, 0);
		} 
		else 
		{
			descending = true;
		}
	}
}