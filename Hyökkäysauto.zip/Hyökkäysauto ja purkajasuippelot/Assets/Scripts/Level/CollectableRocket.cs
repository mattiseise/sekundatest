﻿using UnityEngine;
using System.Collections;

public class CollectableRocket : MonoBehaviour
{
	public PlayerController playerCtrl;
	public RocketsQuantity rockets;

	void OnCollisionEnter2D (Collision2D col)
	{
		if(col.gameObject.layer == 8)
		{
			playerCtrl.rockets += 1;
			rockets.updateText();
			Destroy(gameObject);
		}
	}
}
