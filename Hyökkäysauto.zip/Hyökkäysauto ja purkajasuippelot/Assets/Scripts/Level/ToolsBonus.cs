﻿using UnityEngine;
using System.Collections;

public class ToolsBonus : MonoBehaviour 
{
	public PlayerController playerCtrl;
	public float toolsBonus;
		
	void OnCollisionEnter2D(Collision2D col)
	{
		if (col.gameObject.name == "Player") 
		{
			playerCtrl.hp += toolsBonus;
			Destroy (gameObject);
		}
	}
}