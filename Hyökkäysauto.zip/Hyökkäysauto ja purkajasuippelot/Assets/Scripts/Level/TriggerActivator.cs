﻿using UnityEngine;
using System.Collections;

public class TriggerActivator : MonoBehaviour 
{
	public GameObject gameObjectToBeActivated;
	public bool deactivate;

	void Update()
	{
		Debug.DrawLine(transform.position, new Vector2 (transform.position.x + 1, transform.position.y), Color.red);
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.gameObject.layer == 8 && gameObjectToBeActivated == true && deactivate == false)
		{
			gameObjectToBeActivated.SetActive(true);
		}
		else if(col.gameObject.layer == 8 && gameObjectToBeActivated == true && deactivate == true)
		{
			gameObjectToBeActivated.SetActive(false);
		}
	}
}