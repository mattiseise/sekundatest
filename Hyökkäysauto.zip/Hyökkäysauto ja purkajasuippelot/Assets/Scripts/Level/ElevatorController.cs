﻿using UnityEngine;
using System.Collections;

public class ElevatorController : MonoBehaviour 
{
	public GameObject player;
	private float dist;
	public float targetDist;
	public bool readyToControl;
	public float minHeight;
	public float maxHeight;
	public float elevatorSpeed;

	void Start () 
	{
		minHeight = transform.position.y;
	}
		
	void FixedUpdate () 
	{
		if(player == true)
		{
			dist = Vector2.Distance (player.transform.position, transform.position);
		}

		if (dist < targetDist) 
		{
			readyToControl = true;
		} 
		else
		{
			readyToControl = false;
		}

		float yInput = Input.GetAxis ("Vertical");

		if (readyToControl == true && yInput > 0 && transform.position.y < maxHeight && player == true) 
		{
			player.transform.position = new Vector2(player.transform.position.x, transform.position.y);
			transform.position = new Vector2(transform.position.x, player.transform.position.y + yInput / elevatorSpeed);
		}
		else if(readyToControl == true && yInput < 0 && transform.position.y > minHeight && player == true)
		{
			player.transform.position = new Vector2(player.transform.position.x, transform.position.y);
			transform.position = new Vector2(transform.position.x, player.transform.position.y + yInput / elevatorSpeed);
		}

		if (readyToControl == false && transform.position.y > minHeight) 
		{
			transform.position = new Vector2(transform.position.x, transform.position.y - elevatorSpeed * Time.deltaTime);
		}
	}
}