﻿using UnityEngine;
using System.Collections;

public class FirePlatform : MonoBehaviour 
{
	public PlayerController playerCtrl;
	public float damage;

	void OnCollisionStay2D(Collision2D col)
	{
		if (col.gameObject.layer == 8)
		{
			playerCtrl.hp -= damage;
		}
	}
}