﻿using UnityEngine;
using System.Collections;

public class ElevatorTrigger : MonoBehaviour 
{
	public ElevatorController elevator;
	public float minHeight;
	public float maxHeight;

	void OnTriggerEnter2D (Collider2D col)
	{
		if(col.gameObject.layer == 8)
		{
			elevator.minHeight = minHeight;
			elevator.maxHeight = maxHeight;
		}
	}
}
