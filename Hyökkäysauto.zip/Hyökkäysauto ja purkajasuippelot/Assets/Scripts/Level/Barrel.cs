﻿using UnityEngine;
using System.Collections;

public class Barrel : MonoBehaviour
{
	private SpriteRenderer spriteRend;
	public Sprite barrel;
	public Sprite brokenBarrel;
	public Sprite destroyedBarrel;
	public int maxHp;
	public int hp;
	private BoxCollider2D boxCol;
	private Rigidbody2D rigid;
	private bool exploded;
	public float explosionPower;
	public float barrelSpinningSpeed;
	private Vector2 startPos;
	private float spawnDist;
	public float fallDist;

	void Awake ()
	{
		spriteRend = GetComponent<SpriteRenderer> ();
		boxCol = GetComponent<BoxCollider2D>();
		rigid = GetComponent<Rigidbody2D>();
	}

	void Start () 
	{
		spriteRend.sprite = barrel;
		hp = maxHp;
		exploded = false;
		startPos = transform.position;
	}

	void Update () 
	{
		if (hp < maxHp && hp > 0) 
		{
			spriteRend.sprite = brokenBarrel;
		} 
		else if (hp <= 0) 
		{
			spriteRend.sprite = destroyedBarrel;
			boxCol.enabled = false;
			if(exploded == false)
			{
				exploded = true;
				rigid.AddForce(transform.up * explosionPower);
			}
			transform.Rotate(0, 0, -barrelSpinningSpeed);
			spawnDist = Vector2.Distance (startPos, transform.position);
			if(spawnDist > fallDist)
			{
				Destroy(gameObject);
			}
			rigid.constraints = ~RigidbodyConstraints2D.FreezePositionY;
		}
	}

	void OnCollisionEnter2D(Collision2D col)
	{
		if(col.gameObject.name == "Plasma Bullet(Clone)")
		{
			hp -= 1;
			Destroy(col.gameObject);
		}
		else if(col.gameObject.name == "Rocket(Clone)")
		{
			hp = 0;
			Destroy(col.gameObject);
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.gameObject.name == "Spikes")
		{
			hp -= 2;
		}
	}
}