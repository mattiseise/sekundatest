﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Timer : MonoBehaviour 
{
	private Text timeText;
	public float time;
	public bool stopTime;

	void Awake ()
	{
		timeText = GetComponent<Text> ();
	}

	void Start ()
	{
		time = Time.timeSinceLevelLoad;
	}

	void Update () 
	{
		if(stopTime == false)
		{
			time = Time.timeSinceLevelLoad;
			time = Mathf.Round(time * 10f) / 10f;
		}
		timeText.text =  "Time: " + time.ToString();
	}
}
