﻿using UnityEngine;
using System.Collections;

public class GasMeter : MonoBehaviour 
{
	public PlayerController playerCtrl;
	private RectTransform rect;

	void Awake ()
	{
		rect = GetComponent<RectTransform> ();
	}
	
	void Update () 
	{
		rect.transform.localScale = new Vector2(Mathf.Clamp(calculatePercentage(), 0.0f, 1.0f), transform.localScale.y);
	}

	float calculatePercentage()
	{
		return playerCtrl.gas / playerCtrl.maxGas;
	}
}