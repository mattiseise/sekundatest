﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class RocketsQuantity : MonoBehaviour 
{
	private Text text;
	public PlayerController playerCtrl;

	void Awake () 
	{
		text = GetComponent<Text> ();
	}

	public void updateText()
	{
		if(text == true)
		{
			text.text = "Rockets: " + playerCtrl.rockets.ToString ();
		}
	}
}