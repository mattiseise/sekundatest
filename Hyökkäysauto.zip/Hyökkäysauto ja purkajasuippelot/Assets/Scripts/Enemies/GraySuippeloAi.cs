﻿using UnityEngine;
using System.Collections;

public class GraySuippeloAi : MonoBehaviour
{
	private Vector2 startPos;

	public bool patroller;
	private bool patrol;
	public GameObject player;
	public PlayerController playerCtrl;

	public int maxHp;
	public int hp;
	public float damage;

	public float patrolDist;
	public bool updatePatrolDist;
	private float minPatrolDist;
	private float maxPatrolDist;
	private bool patrolRight;

	public float movementSpeed;
	public float jumpPower;
	private float dist;
	public float targetDist;
	public float attackDist;
	private bool readyToAttack;
	private Rigidbody2D rigid;
	public float attackSpeed;
	public float attackJumpPower;
	public float jumpRayLength;
	public LayerMask layerMask;
	private Vector3 offset;
	private Vector3 positiveOffset = new Vector3(0.08f, 0, 0);
	private Vector3 negativeOffset = new Vector3(-0.08f, 0, 0);

	private PolygonCollider2D polygonCol;
	private bool dead;
	public float corpseFlyingPower;
	public float corpseSpinningSpeed;
	private float spawnDist;
	public float fallDist;
	private bool colliderTimerReturned;
	private float colliderDisappearTime;

	void Awake ()
	{
		rigid = GetComponent<Rigidbody2D> ();
		polygonCol = GetComponent<PolygonCollider2D> ();
	}

	void Start ()
	{
		startPos = transform.position;
		hp = maxHp;
		rigid.freezeRotation = true;
		minPatrolDist = transform.position.x - patrolDist;
		maxPatrolDist = transform.position.x + patrolDist;
		if(patroller == true)
		{
			patrol = true;
			patrolRight = true;
		}
	}

	void FixedUpdate ()
	{
		if(updatePatrolDist == true)
		{
			UpdatePatrolDist();
		}

		Debug.DrawLine(new Vector2(minPatrolDist, transform.position.y), new Vector2(maxPatrolDist, transform.position.y), Color.red);

		if(hp > 0)
		{

			if(patrol == true && patrolRight == true && transform.position.x < maxPatrolDist)
			{
				transform.eulerAngles = new Vector2(0, 180);
				transform.Translate(-movementSpeed * Time.deltaTime, 0, 0);
			}
			else if(patrol == true  && patrolRight == true && transform.position.x > maxPatrolDist)
			{
				patrolRight = false;
			}

			if(patrol == true && patrolRight == false && transform.position.x > minPatrolDist)
			{
				transform.eulerAngles = new Vector2(0, 0);
				transform.Translate(-movementSpeed * Time.deltaTime, 0, 0);
			}
			else if(patrol == true && patrolRight == false && transform.position.x < minPatrolDist)
			{
				patrolRight = true;
			}

			if(player == true)
			{
				dist = Mathf.Abs(player.transform.position.x - transform.position.x);
			}
			if (dist < targetDist && player == true) 
			{
				patrol = false;
				readyToAttack = true;
			}
			else if(patroller == true)
			{
				patrol = true;
				readyToAttack = false;
			}
			else
			{
				patrol = false;
				readyToAttack = false;
			}

			if (readyToAttack == true && dist > attackDist) 
			{
				transform.Translate (-attackSpeed * Time.deltaTime, 0, 0);
				if (checkJump() == true) 
				{
					rigid.AddForce (transform.up * attackJumpPower);
				}
			}
			else if(readyToAttack == true && dist < attackDist)
			{
				transform.Translate(-attackSpeed * Time.deltaTime, 0, 0);
				if(checkJump() == true)
				{
					rigid.AddForce (transform.up * attackJumpPower);
				}
			}

			if (player == true && readyToAttack == true && transform.position.x > player.transform.position.x && attackDist < dist) 
			{
				transform.eulerAngles = new Vector2(transform.eulerAngles.x, 0.0f);
			} 
			else if(player == true && readyToAttack == true && attackDist < dist)
			{
				transform.eulerAngles = new Vector2(transform.eulerAngles.x, 180.0f);
			}

			if(patroller == true && checkJump() == true)
			{
				rigid.AddForce(transform.up * jumpPower);
			}
		}

		if(hp <= 0)
		{
			if(Time.time > GetColliderTime())
			{
				polygonCol.enabled = false;
			}

			if(dead == false)
			{
				dead = true;
				rigid.AddForce(transform.up * corpseFlyingPower);
			}
			transform.Rotate(0, 0, corpseSpinningSpeed);
			patroller = false;
			spawnDist = Vector2.Distance (startPos, transform.position);
			if(spawnDist > fallDist)
			{
				Destroy(gameObject);
			}
		}

		if(transform.eulerAngles.y == 0)
		{
			Debug.DrawRay (transform.position + offset, new Vector2(0, -jumpRayLength), Color.red);
		}
		else 
		{
			Debug.DrawRay (transform.position + negativeOffset, new Vector2(0, -jumpRayLength), Color.red);
		}
	}

	bool checkJump()
	{
		if(transform.eulerAngles.y == 0)
		{
			offset = positiveOffset;
		}
		else 
		{
			offset = negativeOffset;
		}

		RaycastHit2D hit = Physics2D.Raycast (transform.position + offset, Vector2.down, jumpRayLength, layerMask);

		if (hit == true) 
		{
			return true;
		}

		else
		{
			return false;
		}
	}

	void OnCollisionEnter2D(Collision2D col)
	{
		if (col.gameObject.layer == 8)
		{
			playerCtrl.hp -= damage;
		}

	    else if(col.gameObject.name == "Plasma Bullet(Clone)")
		{
			hp -= 1;
			Destroy(col.gameObject);
		}

		else if(col.gameObject.name == "Rocket(Clone)")
		{
			hp = 0;
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.gameObject.name == "Spikes")
		{
			hp -= 2;
		}
	}

	void UpdatePatrolDist()
	{
		if(updatePatrolDist == true)
		{
			transform.position = startPos;
			minPatrolDist = transform.position.x - patrolDist;
			maxPatrolDist = transform.position.x + patrolDist;
			updatePatrolDist = false;
		}
	}

	float GetColliderTime()
	{
		if(colliderTimerReturned == false)
		{
			colliderTimerReturned = true;
			colliderDisappearTime = Time.time;
			return colliderDisappearTime;
		}
		return colliderDisappearTime;
	}
}