﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class BestTimeText : MonoBehaviour 
{
	private Text bestTimeText;

	void Awake ()
	{
		bestTimeText = GetComponent<Text>();
	}

	void Start () 
	{
		if (System.IO.File.Exists ("./bestTime.txt")) 
		{
			if(System.IO.File.ReadAllText ("./bestTime.txt") != "")
			{
				bestTimeText.text = "Best Time: " + float.Parse(System.IO.File.ReadAllText ("./bestTime.txt")).ToString();
			}
		}
		else 
		{
			System.IO.File.WriteAllText ("./bestTime.txt", "");
		}
	}
}
