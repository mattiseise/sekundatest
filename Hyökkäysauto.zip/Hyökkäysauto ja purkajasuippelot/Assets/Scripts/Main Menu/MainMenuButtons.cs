﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class MainMenuButtons : MonoBehaviour
{
	public GameObject bestTimeText;
	public GameObject startButton;
	public GameObject controlsButton;
	public GameObject exitButton;
	public GameObject controlsText;
	public GameObject backButton;

	public void OnClickStart ()
	{
		SceneManager.LoadScene("Hyökkäysauto");
	}

	public void OnClickControls ()
	{
		bestTimeText.SetActive(false);
		startButton.SetActive(false);
		exitButton.SetActive(false);
		controlsText.SetActive(true);
		backButton.SetActive(true);
		gameObject.SetActive(false);
	}

	public void OnClickBack ()
	{
		bestTimeText.SetActive(true);
		startButton.SetActive(true);
		controlsButton.SetActive(true);
		exitButton.SetActive(true);
		controlsText.SetActive(false);
		backButton.SetActive(false);
		gameObject.SetActive(false);
	}

	public void OnClickExit ()
	{
		Application.Quit();
	}
}